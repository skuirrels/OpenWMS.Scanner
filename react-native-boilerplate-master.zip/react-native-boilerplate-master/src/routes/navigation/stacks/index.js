import { HomeNavigator, ProfileNavigator } from './Stacks'

export { HomeNavigator, ProfileNavigator }
